<?= $this->extend('layout') ?>

<?= $this->section('apples') ?>
<h1><?= $testString ?></h1>
<?= $this->endSection() ?>
