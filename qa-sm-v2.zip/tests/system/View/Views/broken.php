<?= $this->extend('layout') ?>

<h1><?= $testString ?></h1>
<?= $this->endSection() ?>
