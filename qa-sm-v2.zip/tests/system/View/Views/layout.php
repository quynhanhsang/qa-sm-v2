<p>Open</p>
<?= $this->renderSection('content') ?>
<p><?= $testString ?></p>
