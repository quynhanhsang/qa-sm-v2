<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<p>First</p>
<?= $this->endSection() ?>


<?= $this->section('content') ?>
<p>Second</p>
<?= $this->endSection() ?>
