<?= $this->extend('layout') ?>

<?= $this->section('content') ?>

	<?= $this->include('simple') ?>

<?= $this->endSection() ?>
