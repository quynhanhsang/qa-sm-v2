<?= $this->extend('layout') ?>

<?= $this->section('content') ?>
<h1><?= $testString ?></h1>
<?= $this->endSection() ?>
