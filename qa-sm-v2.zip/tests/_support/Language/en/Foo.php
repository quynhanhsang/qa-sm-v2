<?php

return [
   'bar'             => 'Foo Bar Translated',
   'bar.min_length1' => 'The {field} field is very short.',
   'bar.min_length2' => 'Supplied value ({value}) for {field} must have at least {param} characters.',
];
