##################
Building Responses
##################

View components are used to build what is returned to the user.

.. toctree::
    :titlesonly:

    views
    view_cells
    view_renderer
    view_layouts
    view_parser
    table
    response
    api_responses
    localization
    alternative_php
