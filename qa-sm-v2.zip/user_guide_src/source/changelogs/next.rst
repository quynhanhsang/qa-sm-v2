Version |version|
====================================================

Release Date: Not released

**Next release of CodeIgniter4**


The list of changed files follows, with PR numbers shown.


PRs merged:
-----------
