#####################
Extending CodeIgniter
#####################

CodeIgniter 4 has been designed to be easy to extend or build upon.

.. toctree::
    :titlesonly:

    core_classes
    common
    events
    basecontroller
    authentication
    contributing
