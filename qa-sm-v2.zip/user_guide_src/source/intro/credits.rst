#######
Credits
#######

CodeIgniter was originally developed by `EllisLab  <https://ellislab.com/>`_.
The framework was written for performance in the real world,
with many of the original class libraries, helpers, and
sub-systems borrowed from the code-base of `ExpressionEngine
<https://expressionengine.com>`_.
It was, for years, developed and maintained by EllisLab, the ExpressionEngine
Development Team and a group of community members called the Reactor Team.

In 2014, CodeIgniter was acquired by the `British Columbia Institute of Technology
<https://www.bcit.ca/>`_ and was then officially announced as a community-maintained
project.

In 2019, the CodeIgniter Foundation was formed to provide a perpetual managing group
separate from any other entity to help ensure the framework's future.
