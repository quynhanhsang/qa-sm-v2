#######
Testing
#######

CodeIgniter ships with a number of tools to help you test and debug your application thoroughly. 
The following sections should get you quickly testing your applications.

.. toctree::
    :titlesonly:

    Getting Started <overview>
    Database <database>
    Controller Testing <controllers>
    HTTP Testing <feature>
    benchmark
    debugging
