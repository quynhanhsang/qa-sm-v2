#############
Modeling Data
#############

CodeIgniter comes with rich tools for modeling and working
with your database tables and records.

.. toctree::
    :titlesonly:

    Using CodeIgniter's Model <model>
    Using Entity Classes <entities>
