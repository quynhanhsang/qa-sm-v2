##################
Managing Databases
##################

CodeIgniter comes with tools to restructure or seed your database.

.. toctree::
    :titlesonly:

    Database Manipulation with Database Forge <forge>
    Database Migrations <migration>
    Database Seeding <seeds>
