##################
Command Line Usage
##################

CodeIgniter 4 can also be used with command line programs.

.. toctree::
    :titlesonly:

    cli
    cli_commands
    cli_library
    cli_request
